
package final5;

import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class readfile {
    
    private Scanner input;
    
    public void open(String name){
        try{
            input=new Scanner(name);
        }catch(SecurityException ex){
            
        }
    }
    
    public void save(){
        try{
            while(input.hasNextLine()){
                String s=input.nextLine();
                System.out.println(s);
            }
        }catch(NoSuchElementException ex){
            
        }catch(IllegalStateException ex){
            
        }
    }
    
    public void close(){
        if(input!=null)
            input.close();
    }
}
