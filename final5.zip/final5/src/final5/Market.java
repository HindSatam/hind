
package final5;

public interface Market{
    
    public abstract void printTotal();
}