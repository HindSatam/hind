
package final5;

import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.FormatterClosedException;

public class writeFile {
    
    private Formatter output;
    
    public void open(String name){
      try{
            output=new Formatter(name);
      }catch(FileNotFoundException ex){
          
      }
       
    }
    
    public void write(Market m){
        try{
            output.format(m.toString());
            System.out.println("cretaed");
        }catch(FormatterClosedException ex){
            
        }
    }
    
    public void close(){
        if(output!=null)
            output.close();
    }
            
            
}
