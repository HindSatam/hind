
package final5;

public class Grocery extends MarketRocelpt{
    
    private Date ExpiryData;

    public Grocery(Date ExpiryData, int MarketID, int quantity, double price) {
        super(MarketID, quantity, price);
        this.ExpiryData = ExpiryData;
    }

    public Date getExpiryData() {
        return ExpiryData;
    }

    public void setExpiryData(Date ExpiryData) {
        this.ExpiryData = ExpiryData;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    
    
    @Override
    public double CalculatePrice() {
        if(ExpiryData.getMounth()<5){
            return(price/2);
        }
        return price;
    }

   
    
    
}
