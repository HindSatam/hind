
package final5;

public class Clothing extends MarketRocelpt{
    
    private String size;

    public Clothing(String size, int MarketID, int quantity, double price) {
        super(MarketID, quantity, price);
        while(size.equals("S")&&size.equals("M")&&size.equals("L")&&size.equals("XL")){
        this.size = size;
    }}

    @Override
    public double CalculatePrice() {
        return 0; 
    }
}

