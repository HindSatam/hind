
package final5;

public class Date {
    
    private int day;
    private int mounth;
    private int year;

    public Date(int day, int mounth, int year) {
        this.day = day;
        this.mounth = mounth;
        this.year = year;
    }
    

    @Override
    public String toString() {
        return "Date:" + "day=" + day + ", mounth=" + mounth + ", year=" + year;
    }

    public int getMounth() {
        return mounth;
    }

    public void setMounth(int mounth) {
        this.mounth = mounth;
    }
    
    
}
