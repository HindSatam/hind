
package final5;

 public abstract class MarketRocelpt implements Market{
    
    private int MarketID;
    private int quantity;
    double price;

    public MarketRocelpt(int MarketID, int quantity, double price) {
        this.MarketID = MarketID;
        this.quantity = quantity;
        this.price = price;
    }

    @Override
    public String toString() {
        return "MarketRocelpt:" + "MarketID=" + MarketID + ", quantity=" + quantity + ", price=" + price ;
    }
   
    public abstract double CalculatePrice();
    
    @Override
    public void printTotal(){
        System.out.println(CalculatePrice()*quantity);
    }
    
}
