
package final5;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class writebinary {
    
    private ObjectOutputStream output;
    
    public void open(String name){
        try{
            output=new ObjectOutputStream(new FileOutputStream(name));
        }catch(FileNotFoundException ex){
            
        }catch(IOException ex){
            
        }
    }
    
    public void write(Market m){
      try{
          output.writeObject(m);
      }catch(IOException ex){
          
      }
    }
    
    public void close(){
        try{
        if(output!=null)
            output.close();
        }catch(IOException ex){
            
        }
    }
}
