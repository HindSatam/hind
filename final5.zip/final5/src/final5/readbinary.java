
package final5;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class readbinary {
    
    private ObjectInputStream input;
    
    public void open(String name){
        try{
            input=new ObjectInputStream(new FileInputStream(name));
        } catch(IOException ex){
            
        }
   }
    
    public ArrayList<Market> save(){
        ArrayList<Market> arr=new ArrayList<>();
       try{
        
        while(true){
            Market m=(Market)input.readObject();
            arr.add(m);
        }
       }catch(EOFException ex){
                
                }catch(ClassNotFoundException ex){
                    
                }catch(IOException ex){
                    
                }
        return arr;
      
    }
    
    public void close(){
        try{
        if(input!=null)
            input.close();
        }catch(IOException ex){
            
        }
    }
    
    
}
