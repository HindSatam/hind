
package final5;

import java.util.ArrayList;

public class main {
    
    public static void main(String[] args) {
        
        ArrayList<Market> list=new ArrayList<>();
        list.add(new Grocery(new Date(3, 4, 2000),1111,5,5.0));
        list.add(new Clothing("S", 222, 3, 8.0));
        
        for (Market market : list) {
            System.out.println(market);
        }
        
        
        
        //files
        
        writeFile w=new writeFile();
        w.open("final5.txt");
        for (Market market : list) {
            w.write(market);
        }
        w.close();
        
        readfile r=new readfile();
        r.open("final5.txt");
        r.save();
        r.close();
        
        //binary
        writebinary wb=new writebinary();
        wb.open("final5.txt");
        wb.write(new Grocery(new Date(3, 4, 2000),1111,5,5.0));
        wb.close();
        
        readbinary rb=new readbinary();
        rb.open("final5.txt");
        rb.save();
        rb.close();
    }
}
